import sys
sys.path.append("lbl")
import pygame
import spielfeld
from pygame.locals import *

class Main:
	def __init__(self):
		pygame.init()
		self.screen = pygame.display.set_mode((600,600))
		self.clock=pygame.time.Clock()
		self.FarbeTot = (0, 0, 0)
		self.FarbeLebend=(250,0,0)
		self.feld=spielfeld.Spielfeld()
		
		
	def loop(self):
		self.background = pygame.Surface(self.screen.get_size())
		self.background = self.background.convert()
		self.background.fill((0,0,0))
		
		while 1:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					sys.exit()
			self.clock.tick(10)
			self.screen.blit(self.background, (0, 0))
			
			for x in range (60):
				for y in range(60):
					if self.feld.felder[y][x]==1:
						rect=pygame.Rect(10*x,10*y,10,10)
						pygame.draw.rect(self.screen,self.FarbeLebend,rect)
					else:
						rect=pygame.Rect(10*x,10*y,10,10)
						pygame.draw.rect(self.screen,self.FarbeTot,rect)
					
			for x in range(60):
				for y in range(60):
					nachbarn=0
					if x-1>=0:
						if self.feld.felder[x-1][y]==1:
							nachbarn=nachbarn+1
					
					if x+1<=59:
						if self.feld.felder[x+1][y]==1:
							nachbarn=nachbarn+1
					
					if y-1>=0:
						if self.feld.felder[x][y-1]==1:
							nachbarn=nachbarn+1
					
					if y+1<=59:
						if self.feld.felder[x][y+1]==1:
							nachbarn=nachbarn+1
					
					if (x-1>=0)and(y-1>=0):
						if self.feld.felder[x-1][y-1]==1:
							nachbarn=nachbarn+1
					
					if (x+1<=59)and(y-1>=0):
						if self.feld.felder[x+1][y-1]==1:
							nachbarn=nachbarn+1
					
					if (x-1>=0)and(y+1<=59):
						if self.feld.felder[x-1][y+1]==1:
							nachbarn=nachbarn+1
					
					if (x+1<=59)and(y+1<=59):
						if self.feld.felder[x+1][y+1]==1:
							nachbarn=nachbarn+1
				
							
					if (self.feld.felder[x][y]==0) and  (nachbarn==3):
						self.feld.felderz[x][y]=1
					if(self.feld.felder[x][y]==0) and  (nachbarn<>3):
						self.feld.felderz[x][y]=0
					if (self.feld.felder[x][y]==1) and (nachbarn<2):
						self.feld.felderz[x][y]=0
					if (self.feld.felder[x][y]==1) and ((nachbarn==2) or (nachbarn==3)):
						self.feld.felderz[x][y]=1
					if (self.feld.felder[x][y]==1)and(nachbarn>3):
						self.feld.felderz[x][y]=0
			#self.feld.felder=self.feld.felderz
			for x in range(60):
				for y in range(60):
					self.feld.felder[x][y]=self.feld.felderz[x][y]
					
						
							
			
			
			pygame.display.flip()
			
if __name__ == "__main__":
	MainWindow = Main()
  	MainWindow.loop()